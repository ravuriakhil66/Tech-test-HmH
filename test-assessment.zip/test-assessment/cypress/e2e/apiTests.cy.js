describe("create account", () => {
  it("test list qoutes endpoint ", () => {
    cy.request({
      method: "GET",
      url: Cypress.env("host") + "/qoutes",
      headers: { Content0type: "application/json" },
    }).then((response) => {
      expect(response.status).to.equal(200);
      expect(response.body.quotes[0].body).to.have.property(
        "body",
        "Talk is cheap. Show me the code"
      );
      expect(response.body.quotes[0].id).to.greaterThan(0);
      expect(response.body.quotes[0].id).to.not.be.null;
    });
  });

  it("test fav quote endpoint with valid id", () => {
    cy.request({
      method: "PUT",
      url: Cypress.env("host") + "/quotes/4/fav",
      headers: {
        "Content-Type": "application/json",
      },
    }).then(function (response) {
      expect(response.statuc).to.equal(200);
      expect(response.body.author).to.equal("Albert Einstein");
      expect(response.body.quotes[0].id).to.greaterThan(0);
      expect(response.body.quotes[0].id).to.not.be.null;
      expect(response.body.body).to.equal(
        "Make everything as simple as possible"
      );
      expect(response.body.user_details.favorite).to.equal(true);
    });
  });

  it("test fav quote endpoint with invalid id", () => {
    cy.request({
      method: "PUT",
      url: Cypress.env("host") + "/quotes/0/fav",
      headers: {
        "Content-Type": "application/json",
      },
    }).then(function (response) {
      expect(response.body.error_code).to.equal(40);
      expect(response.body).to.have.property("message", "Quote not found.");
    });
  });

  it("test unfav quote as a user's favorite", () => {
    cy.request({
      method: "PUT",
      url: Cypress.env("host") + "/quotes/0/unfav",
      headers: {
        "Content-Type": "application/json",
      },
    }).then(function (response) {
      expect(response.body).to.have.property(
        "message",
        "Make everything as simple as possible, but not simpler."
      );
      expect(response.body.user_details.favorite).to.equal(false);
    });
  });

  it("test unfav quote as a user's favorite with invalid id", () => {
    cy.request({
      method: "PUT",
      url: Cypress.env("host") + "/quotes/0/unfav",
      headers: {
        "Content-Type": "application/json",
      },
    }).then(function (response) {
      expect(response.body).to.have.property(
        "message",
        "Private quotes cannot be unfav'd."
      );
      expect(response.body.error_code).to.equal(41);
    });
  });
});
